
export ORACLE_HOME=/u01/app/oraemcc/product/13.3/Middleware
export ORACLE_TERM=xterm
export PATH=${PATH}:$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/bin
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$ORACLE_HOME/lib:$ORACLE_HOME/oracm/lib:/lib:/usr/lib:/usr/local/lib
export NLS_LANG=Spanish_spain.we8iso8859p15

umask 022

##########################




FECHA=`date '+%Y%m%d'`

DIREC=/home/oraemcc/graficORA
# bbdd=DW

array_bbdd=( DW SISS )

cd $DIREC

for BBDD in "${array_bbdd[@]}"
do
 # sqlplus perfstat/perfstat@$BBDD < ./SQL/por_Hora.sql > ./LOG/$BBDD/por_Hora.LOG
 
	sqlplus perfstat/perfstat@$BBDD < ./SQL/por_Dia.sql > ./LOG/$BBDD/por_Dia.$FECHA.LOG

	sqlplus perfstat/perfstat@$BBDD < ./SQL/proc_diario.sql > ./LOG/$BBDD/proc_diario.$FECHA.LOG
	
	ORADIR=/u02/app/oracle/admin/$BBDD/exp
	
	logfi=./LOG/$BBDD/por_Dia.$FECHA.LOG
	
	pro_linea=`grep -n "Load Profile" $logfi | awk -F":" '{print $1}'`
	profin_linea=`grep -n Transactions $logfi | awk -F":" '{print $1}'`
	
	awk -v var=$pro_linea -v var_f=$profin_linea 'NR>=var&&NR<=var_f' $logfi | awk 'NR > 2' | awk ' {print $1"|"$2"|"$3}' > /tmp/kk.csv
	
	case $BBDD in
	DW) scp -p  /tmp/kk.csv oradw@v409pro01exp102.admin.consejeria.jda:$ORADIR ;;
	SISS) scp -p  /tmp/kk.csv orasiss@v408pro01exp102.admin.consejeria.jda:$ORADIR ;;
	esac
	
	# scp -p  /tmp/kk.csv oradw@v409pro01exp102.admin.consejeria.jda:$ORADIR
	
	rm -f $logfi
	
	sqlplus perfstat/perfstat@$BBDD < ./SQL/load_prof.sql > ./LOG/$BBDD/loadPROF.$FECHA.LOG

done




