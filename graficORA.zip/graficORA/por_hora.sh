
export ORACLE_HOME=/u01/app/oraemcc/product/13.3/Middleware
export ORACLE_TERM=xterm
export PATH=${PATH}:$ORACLE_HOME/bin:$ORACLE_HOME/OPatch:$HOME/bin
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$ORACLE_HOME/lib:$ORACLE_HOME/oracm/lib:/lib:/usr/lib:/usr/local/lib
export NLS_LANG=Spanish_spain.we8iso8859p15

umask 022

##########################

DIREC=/home/oraemcc/graficORA
# bbdd=DW

array_bbdd=( DW SISS )  






cd $DIREC

# sqlplus perfstat/perfstat@$bbdd < ./SQL/por_Hora.sql > ./LOG/$bbdd/por_Hora.LOG

for BBDD in "${array_bbdd[@]}"
do
 sqlplus perfstat/perfstat@$BBDD < ./SQL/por_Hora.sql > ./LOG/$BBDD/por_Hora.LOG
done
