
execute PERFSTAT.proc_report_porhora;

commit;



