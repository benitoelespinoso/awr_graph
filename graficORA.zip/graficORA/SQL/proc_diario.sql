
execute PERFSTAT.proc_report_diario(sysdate);


commit;

