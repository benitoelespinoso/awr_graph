



set heading off
set trimsp on pages 0
set feedback off;

spool parte.2.txt


select
'{ label: ' ||  '"' || event  || '"' || ', y: ' ||
waits ||
' }, '
from
perfstat.top_n_wait  t
where
trunc(t.fecha,'DD')=trunc(sysdate ,'DD')
order by t.fecha desc, t.waits desc;


spool off;

spool parte.3.txt


select
'{ label: ' ||  '"' || event  || '"' || ', y: ' ||
replace(round(avwait,2),',','.')  ||
' }, '
from
perfstat.top_n_wait  t
where
trunc(t.fecha,'DD')=trunc(sysdate ,'DD')
order by t.fecha desc, t.waits desc;


spool off;


spool queso.1.txt

select * from (
select
'{ y: ' || waits  || ', name: ' || '"' || event || '"' || '},'
from
perfstat.top_n_wait t
where trunc(t.fecha,'DD')=trunc(sysdate ,'DD')
order by waits desc)
where rownum < 15;


spool off;

spool queso.2.txt

select * from (
select
'{ y: ' || replace(round(avwait,2),',','.')  || ', name: ' || '"' || event || '"' || '},'
from
perfstat.top_n_wait t
where trunc(t.fecha,'DD')=trunc(sysdate ,'DD')
order by avwait desc)
where rownum < 15;


spool off;



