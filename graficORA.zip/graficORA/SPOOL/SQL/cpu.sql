

set heading off
set trimsp on pages 0
set feedback off;

spool parte_2.2.txt


select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(total_cpu, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.T_CPU
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;


spool off;




