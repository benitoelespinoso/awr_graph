

set heading off
set trimsp on pages 0
set feedback off;


-- UIO

spool a.wait.uio.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(uio, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;


-- SIO

spool c.wait.sio.txt


select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(sio, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

-- concurren

spool e.wait.conc.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(CONCURRENCY, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

-- app

spool g.wait.app.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(APPLICATION, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

-- commit

spool i.wait.commi.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(commit, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

-- conf.

spool k.wait.conf.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(CONFIGURATION, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

-- network

spool m.wait.net.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(network, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;

spool off;

spool o.wait.oth.txt

select
'{ label: ' || '"' ||
substr(sample_time,12,5) || '"' ||
' , y: ' ||
to_char(other, 'FM999G999G999G990D00', 'nls_numeric_characters=.,') ||
' }, '
from
 perfstat.t_waits
 where
 trunc(to_date(sample_time,'dd-mm-yyyy hh24:mi')) = trunc(sysdate)
order by sample_time asc;


spool off;


