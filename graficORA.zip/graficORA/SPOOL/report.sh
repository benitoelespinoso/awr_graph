


source /home/oraemcc/.bash_profile

##########################

HOY=`date '+%Y%m%d'`

DIREC=/home/oraemcc/PROCHSS/SPOOL

HTTP_DIR=/u01/app/oraemcc/product/13.3/gc_inst/user_projects/domains/GCDomain/config/fmwconfig/components/OHS/instances/ohs1/htdocs/OUT

array_bbdd=( prochss protrxc )

for BBDD in "${array_bbdd[@]}"
do
        cd $DIREC

        sqlplus -s perfstat/perfstat@$BBDD < ./SQL/cpu.sql

                mv parte_2.2.txt ./TXT/b.parte.txt

        sqlplus -s perfstat/perfstat@$BBDD < ./SQL/wait.sql

                for fil in $(ls *wait*txt); do cat $fil >> t_waits.$HOY.html ; done

                mv t_waits.$HOY.html ./TXT/d.parte.txt

        sqlplus -s perfstat/perfstat@$BBDD < ./SQL/topw.sql

                mv parte.2.txt ./TXT/f.parte.txt
                mv parte.3.txt ./TXT/h.parte.txt
                mv queso.1.txt ./TXT/j.parte.txt
                mv queso.2.txt ./TXT/l.parte.txt

        cd $DIREC/TXT

        for fil in $(ls *parte.txt); do cat $fil >> $DIREC/OUT/$BBDD/$BBDD.$HOY.html  ; done

     # cp $DIREC/OUT/$BBDD/$BBDD.$HOY.html $HTTP_DIR/$BBDD/

	 scp $DIREC/OUT/$BBDD/$BBDD.$HOY.html oraemcc@v451pro01ges102.admin.consejeria.jda:$HTTP_DIR/DW

done




